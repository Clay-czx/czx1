package com.zctc.admwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdmworkApplicationTests {

    @Test
    void contextLoads() {
    }

}
