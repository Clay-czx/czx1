package com.zctc.admwork.domain;

public class ValueObject {


}
