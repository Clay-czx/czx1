package com.zctc.admwork.controller;

public class BaseController {
}
