package com.zctc.admwork.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DemoController extends BaseController{

    @GetMapping("/demos/input")
    public String toInput() throws Exception{
        return "input_demo";
    }
}
