package com.zctc.admwork.service;

public class DamoServiceImpl implements DamoService{
}
