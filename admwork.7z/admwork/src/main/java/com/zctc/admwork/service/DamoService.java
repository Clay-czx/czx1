package com.zctc.admwork.service;

public interface DamoService {

}
