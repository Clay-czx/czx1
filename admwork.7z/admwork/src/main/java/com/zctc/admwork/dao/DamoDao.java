package com.zctc.admwork.dao;

import com.zctc.admwork.domain.Damo;

public interface DamoDao {
    void addHotel(Damo damo);
}
