package com.zctc.admwork.domain;

public class Damo extends ValueObject {
    private int damoId;

    public int getDamoId() {
        return damoId;
    }

    public void setDamoId(int damoId) {
        this.damoId = damoId;
    }
}
